from flask import Flask, render_template, send_file, request
import json
import os

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/archive")
def archive():
    if not os.path.exists("bet_archive.json"):
        return render_template("archive.html", bets=[])
    with open("bet_archive.json", "r") as f:
        data = json.load(f)
    return render_template("archive.html", bets=data)

@app.route("/export/json")
def export_json():
    return send_file("bet_archive.json", mimetype="application/json", as_attachment=True)

@app.route("/export/csv")
def export_csv():
    return send_file("exported_bets.csv", mimetype="text/csv", as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
