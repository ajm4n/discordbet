import discord
from discord.ext import commands, tasks
from discord.ui import View, Button, Select, Modal, TextInput
import requests
import os
import uuid
import json
from datetime import datetime
import csv

ODDS_API_KEY = os.getenv("ODDS_API_KEY")
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

BET_FILE = "bet_data.json"
ARCHIVE_FILE = "bet_archive.json"
JSON_EXPORT_FILE = "exported_bets.json"
CSV_EXPORT_FILE = "exported_bets.csv"
parlays = {}  # user_id -> list of parlay legs
bets = []

if os.path.exists(BET_FILE):
    with open(BET_FILE, "r") as f:
        bets = json.load(f)

def save_bets():
    with open(BET_FILE, "w") as f:
        json.dump(bets, f, indent=2)

def archive_bet(bet):
    archive = []
    if os.path.exists(ARCHIVE_FILE):
        with open(ARCHIVE_FILE, "r") as f:
            archive = json.load(f)
    archive.append(bet)
    with open(ARCHIVE_FILE, "w") as f:
        json.dump(archive, f, indent=2)

def fetch_sports():
    url = f"https://api.the-odds-api.com/v4/sports/?apiKey={ODDS_API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    return []

def fetch_odds(sport_key, market_type="h2h"):
    url = f"https://api.the-odds-api.com/v4/sports/{sport_key}/odds/?regions=us&markets={market_type}&oddsFormat=decimal&apiKey={ODDS_API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    return []

def fetch_results(sport_key):
    url = f"https://api.the-odds-api.com/v4/sports/{sport_key}/scores/?daysFrom=1&apiKey={ODDS_API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    return []

def calculate_parlay_odds(legs):
    total_odds = 1.0
    for leg in legs:
        total_odds *= leg['odds']
    return round(total_odds, 2)

@bot.slash_command(name="exportjson", description="Export archived bet history as a JSON file")
@commands.has_permissions(administrator=True)
async def exportjson(ctx):
    if not os.path.exists(ARCHIVE_FILE):
        await ctx.respond("No archived data to export.", ephemeral=True)
        return
    with open(ARCHIVE_FILE, "r") as f:
        archive = json.load(f)
    with open(JSON_EXPORT_FILE, "w") as f:
        json.dump(archive, f, indent=2)
    await ctx.respond(file=discord.File(JSON_EXPORT_FILE), ephemeral=True)

@bot.slash_command(name="exportcsv", description="Export archived bet history as a CSV file")
@commands.has_permissions(administrator=True)
async def exportcsv(ctx):
    if not os.path.exists(ARCHIVE_FILE):
        await ctx.respond("No archived data to export.", ephemeral=True)
        return
    with open(ARCHIVE_FILE, "r") as f:
        archive = json.load(f)
    with open(CSV_EXPORT_FILE, "w", newline='') as csvfile:
        fieldnames = ['user', 'status', 'amount', 'odds', 'timestamp', 'matchup', 'team', 'leg_odds']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for bet in archive:
            for leg in bet['legs']:
                writer.writerow({
                    'user': bet['user'],
                    'status': bet['status'],
                    'amount': bet['amount'],
                    'odds': bet['odds'],
                    'timestamp': bet['timestamp'],
                    'matchup': leg.get('matchup', leg.get('game_id', 'N/A')),
                    'team': leg['team'],
                    'leg_odds': leg['odds']
                })
    await ctx.respond(file=discord.File(CSV_EXPORT_FILE), ephemeral=True)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.command()
async def start(ctx):
    await ctx.send("Use slash commands like /exportjson or /exportcsv to interact with the bot.")

# Run the bot
if __name__ == "__main__":
    if DISCORD_TOKEN:
        bot.run(DISCORD_TOKEN)
    else:
        print("DISCORD_TOKEN environment variable not set.")
